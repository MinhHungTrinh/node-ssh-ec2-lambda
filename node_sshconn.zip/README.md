* Install package
```$xslt
npm install
```
* Install to test at local
```$xslt
npm i -g run-func
run-func index.js handler
```
* Compress source and package to deploy to AWS Lambda:
```$xslt
zip node_sshconn.zip -r .
```

